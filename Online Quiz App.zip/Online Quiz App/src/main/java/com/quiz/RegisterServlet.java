package com.quiz;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private String hashPassword(String password)
            throws NoSuchAlgorithmException {

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes(
                java.nio.charset.StandardCharsets.UTF_8));

        StringBuilder result = new StringBuilder();

        for (byte b : hash) {
            result.append(String.format("%02x", b));
        }

        return result.toString();
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        String fullName = request.getParameter("full_name");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (PrintWriter out = response.getWriter()) {

            if (fullName == null || username == null || password == null
                    || fullName.isBlank() || username.isBlank()
                    || password.isBlank()) {
                out.println("<h3>Please fill in all fields.</h3>");
                out.println("<a href='register.html'>Go back</a>");
                return;
            }

            String sql = "INSERT INTO users "
                    + "(full_name, username, password_hash) "
                    + "VALUES (?, ?, ?)";

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, fullName.trim());
                ps.setString(2, username.trim());
                ps.setString(3, hashPassword(password));

                ps.executeUpdate();

                response.sendRedirect("login.html?registered=1");

            } catch (SQLException e) {
                if ("23000".equals(e.getSQLState())) {
                    out.println("<h3>That username may already be taken.</h3>");
                    out.println("<a href='register.html'>Try again</a>");
                } else {
                    throw new ServletException(
                            "Unable to register user.", e);
                }
            } catch (NoSuchAlgorithmException e) {
                throw new ServletException(
                        "Unable to process password.", e);
            }
        }
    }
}
