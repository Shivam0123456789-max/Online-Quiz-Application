
package com.quiz;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));

        StringBuilder result = new StringBuilder();
        for (byte b : hash) {
            result.append(String.format("%02x", b));
        }

        return result.toString();
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || password == null
                || username.isBlank() || password.isBlank()) {
            response.sendRedirect("login.html?error=1");
            return;
        }

        String sql = "SELECT id, full_name, password_hash "
                   + "FROM users WHERE username = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username.trim());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()
                        && rs.getString("password_hash")
                             .equals(hashPassword(password))) {

                    request.getSession().setAttribute(
                            "userId", rs.getInt("id"));

                    request.getSession().setAttribute(
                            "fullName", rs.getString("full_name"));

                    response.sendRedirect("quiz");

                } else {
                    response.sendRedirect("login.html?error=1");
                }
            }

        } catch (Exception e) {
            throw new ServletException("Unable to log in.", e);
        }
    }
}
